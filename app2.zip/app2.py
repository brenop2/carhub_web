from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from ollama import chat
from pydantic import BaseModel

app = Flask(__name__, static_folder='carhub')
CORS(app)  # Libera CORS para o frontend acessar

# Modelo de resposta esperada
class CarInfo(BaseModel):
    brand: str
    model: str
    engine: str
    year: int | None = None
    transmission: str | None = None
    fuel_type: str | None = None

@app.route('/ask', methods=['POST'])
def ask_car():
    data = request.get_json()
    if not data or 'message' not in data:
        return jsonify({'error': 'Missing "message" field'}), 400

    try:
        response = chat(
            model='llama3',
            messages=[{'role': 'user', 'content': data['message']}],
            format=CarInfo.model_json_schema(),
        )
        car_info = CarInfo.model_validate_json(response.message.content)
        return jsonify(car_info.dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    app.run(debug=True, port=5000)
